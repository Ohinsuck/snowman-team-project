function setup() {
  createCanvas(400, 400);
  fill('white');
  ellipse(200,150,150,150);
  translate(0,150);
  ellipse(200,150,200,200);
  fill(0,0,0);
  ellipse(160,-10,15,15);
  translate(80,0);
  ellipse(160,-10,15,15);
  fill(0,0,0);
  rect(110,15,20,20);
  strokeWeight(4);
  fill(0,0,0);
  line(300,50,220,150);
  strokeWeight(4);
  fill(0,0,0);
  line(-60,50,20,150);
}


function draw() {
  
}